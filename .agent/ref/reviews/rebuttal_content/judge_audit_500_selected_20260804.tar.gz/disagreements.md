# Qwen2.5-72B judge 与宽松复核不一致的题目

正类定义为‘模型答案与标准答案核心一致’。FP 表示 judge 过度接受；FN 表示 judge 过度拒绝。完整问答见 `audit_500_detailed.jsonl` 或 CSV。

## 假阳性（原判 1，复核 0）：15 条

| ID | 数据集 | 模型 | 原始 idx | 题目 | 复核理由 |
|---:|---|---|---|---|---|
| 9 | GUIChat | gemini-2.5-flash | web_guichat_764 | What does the 'TDI mode' mentioned in the context of optical distortions refer to? | 问题询问 TDI 模式所指含义，标准答案是 Time Delay and Integration；答案只谈畸变方向，没有给出该定义。 |
| 27 | GUIChat | gemini-2.5-flash | web_guichat_255 | Is there information available on the website that can help me understand parathyroid surgery? | 标准答案认为页面上的专业论文可帮助理解甲状旁腺手术；答案最终明确给出 No，核心是非结论相反。 |
| 32 | GUIChat | qwen2.5-vl-32b | web_guichat_861 | Where can I find books that are perfect for my love of mystery fiction? | 标准答案要求使用页面上的 Mystery fiction 分类/入口；答案只泛泛推荐外部书店、博客和图书馆，遗漏页面内关键入口。 |
| 49 | GUIChat | qwen2.5-vl-72b | web_guichat_194 | What is the historical significance of the '25 jaar NICC' mentioned on the webpage? | 虽识别出 25 周年，但把 NICC 展开为另一个机构（Netherlands Institute for Cultural Cooperation），与标准答案中的机构身份冲突。 |
| 56 | GUIChat | qwen2.5-vl-32b | web_guichat_528 | Are the servo drives listed for industrial use only, or can they be used for hobbyist projects as well? | 标准答案说明产品主要面向工业但有技能的爱好者也可使用；答案断言 Industrial Use Only，核心适用范围相反。 |
| 57 | GUIChat | qwen2.5-vl-32b | web_guichat_457 | What should I do if I need to cancel my tour less than two weeks in advance? | 答案正确复述取消政策区间，却无依据地把‘不足两周’等同于‘不足 8 天’，并最终判定不退款，不能回答给定情形。 |
| 66 | GUIChat | qwen2.5-vl-3b | web_guichat_496 | How can I sign up or log in to the /e/OS community? | 问题同时询问注册或登录；答案只让用户点击 Sign Up，遗漏已有用户应点击 Log In 的关键操作。 |
| 116 | GUIChat | qwen2.5-vl-3b | web_guichat_373 | What kind of flooring projects might 'Roll Stock Flooring and Off-Cuts' refer to? | 问题询问项目的种类，答案只是重复 Roll Stock Flooring and Off-Cuts 标题，没有说明项目类型。 |
| 150 | GUIChat | claude-4-sonnet | web_guichat_840 | Is there a portfolio I can view to see past reunion events photographed by Rita Thomas? | 标准答案指向 Reunions 标题/图片，答案却引导到 Collections，是不同页面区域和方案。 |
| 166 | GUIChat | gemini-2.5-flash | web_guichat_718 | Are the special prices on home renovations still available? | 标准答案指出仅凭页面无法判断当前是否仍可用；答案直接断言优惠已过期，属于无依据的相反结论。 |
| 173 | GUIChat | qwen2.5-vl-32b | web_guichat_602 | What is the Permanent Portfolio, and how does it relate to the discussions on this forum? | 对 Permanent Portfolio 的创建者和资产构成作了实质性错误说明，虽提到分散投资，但核心定义不正确。 |
| 182 | GUIChat | qwen2.5-vl-7b | web_guichat_36 | What kind of architectural styles are prevalent in King Street, Bristol? | 标准答案明确页面未提供建筑风格信息；答案却编造 Victorian、Neoclassical、Modern 等风格。 |
| 247 | WebMMU | qwen2.5-vl-32b | webmmu_1344 | Is there any difference in the change of price index for January and December over the years of 2019 to 2023? If yes, how much is it? | 问题要求比较一月与十二月的总体趋势/差值；答案改为逐年计算各自 Jan–Dec 差距，回答了不同的计算目标。 |
| 254 | WebMMU | qwen2.5-vl-7b | webmmu_697 | In the top left panel, at the bottom of that page, which player has curly brown hair among the other players? | 问题要求识别卷发球员；答案只给出整块人物面板的大范围坐标，没有指出标准答案中的红鸟/中间球员。 |
| 336 | WebMMU | internvl3-78b | webmmu_420 | If users want to get more information about Approve which is a part of Metrology suite of integrated products how can the webpage help him? | 标准答案要求点击 Approve 项下的 Read more；答案只罗列页面分区，没有给出该关键按钮或操作。 |

## 假阴性（原判 0，复核 1）：31 条

| ID | 数据集 | 模型 | 原始 idx | 题目 | 复核理由 |
|---:|---|---|---|---|---|
| 3 | GUIChat | gemini-2.5-flash | web_guichat_952 | What are 'Wondergirls' known for in the world of music? | 答案正确指出 Wonder Girls 因《Nobody》及进入美国市场而知名，核心信息已覆盖。 |
| 30 | GUIChat | internvl3-78b | web_guichat_770 | How can I protect my health care choices and maintain my privacy? | 答案给出了支持相关倡议组织这一项有效行动；按宽松标准，一项可行的核心行动已足够。 |
| 44 | GUIChat | gpt-5 | web_guichat_701 | How can I subscribe to read the full article on the website? | 答案明确指出点击 digital subscription，核心操作正确。 |
| 69 | GUIChat | qwen2.5-vl-32b | web_guichat_46 | What might 'Love What You Feel' refer to in the context of this webpage? | 答案正确识别《Love What You Feel》为该页面提到的音乐发行内容。 |
| 72 | GUIChat | qwen2.5-vl-72b | web_guichat_165 | Who recently set a new record at the VMAs? | 答案准确给出 Beyoncé，核心实体完全正确。 |
| 75 | GUIChat | qwen2.5-vl-7b | web_guichat_170 | What is the significance of transverse drainage in geological terms? | 答案给出了 transverse drainage 的定义及其作用，已覆盖问题所需核心解释。 |
| 78 | GUIChat | qwen2.5-vl-7b | web_guichat_608 | Can I use this music portal on my phone? | 答案的 Yes 与标准答案核心结论一致。 |
| 102 | GUIChat | qwen2.5-vl-3b | web_guichat_853 | If I wanted to start my own seed collection, how many seeds should I gather to ensure a good chance of germination? | 答案称至少需要 100 粒种子，显然满足标准答案所说的多于两粒；虽更具体，但不矛盾。 |
| 104 | GUIChat | internvl3-78b | web_guichat_629 | Are there any subscription boxes specialized for sensitive skin care mentioned? | 答案正确说明页面没有专门面向敏感肌的订阅盒，核心结论一致。 |
| 113 | GUIChat | gpt-5 | web_guichat_91 | Can I find information on how to celebrate birthdays while birding in Ocean City? | 答案正确指出页面没有关于生日观鸟活动的指导，核心结论一致。 |
| 121 | GUIChat | gpt-5 | web_guichat_19 | What role does personal development play in business success? | 答案正确表达个人发展会延伸并影响商业/职业生活，核心关系一致。 |
| 135 | GUIChat | claude-4-sonnet | web_guichat_481 | How can I get a payday loan for funeral costs from Wage Day Advance? | 答案给出了访问或联系 Wage Day Advance 的可行方式，已满足核心操作要求。 |
| 176 | GUIChat | qwen2.5-vl-72b | web_guichat_73 | What are the four ways to hide cables mentioned in the episode? | 答案正确指出页面没有给出四种隐藏线缆方法的具体细节，与标准答案一致。 |
| 180 | GUIChat | gpt-5 | web_guichat_517 | Can I learn guitar techniques from the artists featured on this webpage? | 答案的 Yes 与标准答案核心结论一致。 |
| 196 | GUIChat | qwen2.5-vl-7b | web_guichat_653 | What is the main image on the webpage about? | 答案把相关图片识别为响应式网站/网站制作主题，与标准答案的‘学习创建网站’核心语义足够接近。 |
| 198 | WebMMU | qwen2.5-vl-32b | webmmu_771 | Based on the current standings in the "2023 Chilean Primera División Stats" table, located in the top-right section of the screenshot, which teams are most likely to secure the to… | 答案抓住了积分与比赛场次变化所体现的主要趋势，核心分析成立。 |
| 199 | WebMMU | gpt-5 | webmmu_452 | Where can a user get the contact info of this webpage? | 答案正确指出可通过 Contact Us/地址信息联系，核心路径一致。 |
| 224 | WebMMU | gemini-2.5-flash | webmmu_199 | **How can I look for offers that the essay writing services might provide for the customers?** | 答案准确识别应点击 Offers 链接，核心操作正确。 |
| 227 | WebMMU | qwen2.5-vl-7b | webmmu_817 | Did all the teams from the central division listed in the image play the same number of total games? | 最终结论 No 与标准答案一致；中间说明虽不够理想，但没有改变所问结论。 |
| 239 | WebMMU | gpt-5 | webmmu_306 | If the users want to read the articles in another language, which option of this website allows them to change it? | 答案正确定位到页面右上方的语言选择器，核心操作正确。 |
| 253 | WebMMU | qwen2.5-vl-3b | webmmu_37 | How does the article suggest balancing your efforts based on what your boss expects versus what others may expect in a Christmas casual job? | 答案强调准时、稳定地完成工作，与老板所期待的核心行为一致。 |
| 274 | WebMMU | qwen2.5-vl-3b | webmmu_964 | Where can users guide themselves to get more information regarding the community's accessibility from this website? | 答案仅给出坐标，但该坐标落在正确的 Accessibility 按钮范围内；最终 prompt 明确不应苛求格式。 |
| 280 | WebMMU | gemini-2.5-flash | webmmu_552 | If an user is trying to learn more about healthcare from the webpage what should they do? | 答案正确识别 Healthcare 导航项，核心页面入口一致。 |
| 286 | WebMMU | internvl3-78b | webmmu_450 | How does the article link recycling to economic advantages for countries like Nigeria and the United States? | 答案涵盖节能、就业等回收利用的经济收益，已包含标准答案核心要点。 |
| 297 | WebMMU | qwen2.5-vl-3b | webmmu_719 | According to the information in the screenshot, If Iraq’s December 2024 supply increases by 10% and UAE’s increases by 5%, what will be their new combined total supply? | 答案计算为 8.022，标准答案为 8.045，差异极小且不改变分析结论；按宽松数值口径接受。 |
| 325 | WebMMU | internvl3-78b | webmmu_265 | How can the user reach out to HENI NEWS in this page? | 答案正确指出页脚的 Contact Us；坐标有偏差，但最终 prompt 明确核心元素文本正确即可。 |
| 352 | WebMMU | internvl3-78b | webmmu_1220 | How can I access the Current Affairs of June 2024 from the webpage? | 答案正确识别 Current Affairs June 链接；多提到 checkbox 不影响核心操作。 |
| 371 | WebMMU | internvl3-78b | webmmu_526 | Where can the user find an indexing service that is related to Google from this webpage? | 答案正确指出 Google Scholar 相关区域/入口，核心信息一致。 |
| 375 | WebMMU | claude-4-sonnet | webmmu_569 | Where is the option to "View Live Lesson" for the Arctic sessions located in the webpage? | 答案正确说明 View Live Lesson 按钮位于课程描述下方，核心位置与操作一致。 |
| 465 | WebMMU | gemini-2.5-flash | webmmu_1221 | How can check out the list of US presidents from this webpage? | 答案正确指出 List of US Presidents 链接，核心入口一致。 |
| 466 | WebMMU | gemini-2.5-flash | webmmu_961 | I want to know about the product Hesperis 'Purple. Where should I look on the page? | 答案正确识别相关产品 Hesperis，核心实体一致。 |

## 无法核验：2 条

| ID | 数据集 | 模型 | 原始 idx | 原因 |
|---:|---|---|---|---|
| 326 | WebMMU | qwen2.5-vl-32b | webmmu_387 | 源记录只有通用任务前缀，没有实质问题，且 gold 为空，无法依据 judge prompt 验证。 |
| 470 | WebMMU | qwen2.5-vl-7b | webmmu_414 | 源记录只有通用任务前缀，没有实质问题，且 gold 为空，无法依据 judge prompt 验证。 |

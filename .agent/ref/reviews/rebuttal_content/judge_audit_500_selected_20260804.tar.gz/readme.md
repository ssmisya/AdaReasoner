# 500 题 Judge 审核产物

主结论：有效 498 题，Qwen2.5-72B judge 与宽松逐条复核的一致率为 **90.76%**；FP=15，FN=31，另有 2 条源记录无法核验。

文件说明：

- `report.md`：中文主报告与总体/分组指标。
- `sampled_questions_500.md`：抽到的 500 个题目清单。
- `sampled_questions_500.csv`：可用 Excel 打开的完整逐题表，含标准答案、模型答案和复核结果。
- `audit_500_detailed.jsonl`：机器可读完整逐题审计记录。
- `disagreements.md`：15 个 FP、31 个 FN 和 2 个无效样本的具体原因。
- `metrics.json`：机器可读总体与分组指标。
- `final_judge_prompt.txt`：最终 judge prompt（占位符形式）。
- `sampling_manifest.json`：抽样参数、源文件、run 行号与哈希。
- `audit_decisions.json`：人工式逐条复核中所有标签翻转与无效记录的理由。
- `checksums.sha256`：主要产物的 SHA-256 校验值。
- `prepare_sample.py`、`build_report.py`：复现抽样和报告生成的脚本。
